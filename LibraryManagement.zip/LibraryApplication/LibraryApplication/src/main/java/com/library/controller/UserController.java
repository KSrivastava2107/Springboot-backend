package com.library.controller;

import com.library.security.EmailService;
import com.library.security.OtpService;
import com.library.model.User;
import com.library.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private OtpService otpService;

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user) {
        userService.saveUser(user);
        return "redirect:/users/login";
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String loginUser(@RequestParam String email, @RequestParam String password, Model model) {
        User user = userService.findByEmail(email);
        if (user != null && user.getPassword().equals(password)) {
            String otp = otpService.generateOtp();
            otpService.storeOtp(email, otp);
            emailService.sendOtpEmail(email, otp);

            // ✅ Pass email in the model for the OTP verification page
            model.addAttribute("email", email);
            return "otp-verification"; // Renders the OTP verification page
        }
        model.addAttribute("error", "Invalid credentials");
        return "login";
    }

    @PostMapping("/verify-otp")
    public String verifyOtp(@RequestParam String email, @RequestParam String otp, Model model) {
        if (otpService.validateOtp(email, otp)) {
            otpService.clearOtp(email); // ✅ Remove OTP after successful verification
            return "redirect:/books";
        }
        model.addAttribute("error", "Invalid OTP");
        model.addAttribute("email", email); // ✅ Ensure email is passed back to the form
        return "otp-verification";
    }
}
