package com.library.service;

import com.library.model.Book;
import com.library.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public Book saveBook(Book book) {
        return bookRepository.save(book);
    }

    public void borrowBook(Long id) {
        Book book = bookRepository.findById(id).orElseThrow(() -> new RuntimeException("Book not found"));
        if (book.isBorrowed()) {
            throw new RuntimeException("Book is already borrowed");
        }
        book.setBorrowed(true);
        book.setIssueDate(LocalDate.now()); // Set the issue date to today
        book.setLastSubmissionDate(LocalDate.now().plusDays(14)); // Set the last submission date to 14 days from today
        bookRepository.save(book);
    }

    public void returnBook(Long id) {
        Book book = bookRepository.findById(id).orElseThrow(() -> new RuntimeException("Book not found"));
        if (!book.isBorrowed()) {
            throw new RuntimeException("Book is not borrowed");
        }
        book.setBorrowed(false);
        book.setActualSubmissionDate(LocalDate.now()); // Set the actual submission date to today

        // Calculate fine if the book is returned late
        if (book.getActualSubmissionDate().isAfter(book.getLastSubmissionDate())) {
            long daysLate = ChronoUnit.DAYS.between(book.getLastSubmissionDate(), book.getActualSubmissionDate());
            double fine = daysLate * 100; // Fine is 100 per day
            book.setFine(fine);
        } else {
            book.setFine(0); // No fine if returned on or before the last submission date
        }

        bookRepository.save(book);
    }

    public void deleteBook(Long id) {
        bookRepository.deleteById(id);
    }
}