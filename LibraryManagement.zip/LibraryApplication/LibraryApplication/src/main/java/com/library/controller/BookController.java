package com.library.controller;

import com.library.model.Book;
import com.library.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/books")
public class BookController {
    @Autowired
    private BookService bookService;

    @GetMapping
    public String listBooks(Model model) {
        model.addAttribute("books", bookService.getAllBooks());
        return "books";
    }

    @PostMapping
    public String addBook(@ModelAttribute Book book) {
        bookService.saveBook(book);
        return "redirect:/books";
    }

    @GetMapping("/borrow/{id}")
    public String borrowBook(@PathVariable Long id) {
        bookService.borrowBook(id);
        return "redirect:/books";
    }

    @GetMapping("/return/{id}")
    public String returnBook(@PathVariable Long id) {
        bookService.returnBook(id);
        return "redirect:/books";
    }
}