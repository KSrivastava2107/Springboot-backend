package com.library.security;

import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Service
public class OtpService {
    private final Map<String, String> otpMap = new HashMap<>();

    public String generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);
        return String.valueOf(otp);
    }

    public void storeOtp(String email, String otp) {
        otpMap.put(email, otp);
    }

    public boolean validateOtp(String email, String otp) {
        return otpMap.containsKey(email) && otpMap.get(email).equals(otp);
    }

    public void clearOtp(String email) {
        otpMap.remove(email); // ✅ Remove OTP after successful verification
    }
}
