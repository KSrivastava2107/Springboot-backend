package com.movieflix.auth.entities;

public enum UserRole {
    USER,
    ADMIN
}
