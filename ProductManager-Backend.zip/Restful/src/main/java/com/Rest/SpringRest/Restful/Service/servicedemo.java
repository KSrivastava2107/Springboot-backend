package com.Rest.SpringRest.Restful.Service;

import com.Rest.SpringRest.Restful.Entity.entitydemo;
import com.Rest.SpringRest.Restful.Repository.repositorydemo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class servicedemo {

    private final repositorydemo repodemo;

    @Autowired
    public servicedemo(repositorydemo repodemo) {
        this.repodemo = repodemo;
    }

    public List<entitydemo> getAllEntities(){
        return repodemo.findAll();
    }

    public entitydemo getEntityById(Long id){
        Optional<entitydemo> entity=repodemo.findById(id);
        if (entity.isPresent()){
            return entity.get();
        }else {
            throw new RuntimeException("Entity Not Found with ID:"+id);
        }
    }

    public entitydemo saveEntity(entitydemo demo){
        return repodemo.save(demo);
    }

    public void deleteEntity(Long id){
        if(!repodemo.existsById(id)){
            throw new RuntimeException("Entity Not Found!"+id);
        }
        repodemo.deleteById(id);
    }

}


