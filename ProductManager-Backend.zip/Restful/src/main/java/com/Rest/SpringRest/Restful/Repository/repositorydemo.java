package com.Rest.SpringRest.Restful.Repository;

import com.Rest.SpringRest.Restful.Entity.entitydemo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface repositorydemo extends JpaRepository<entitydemo,Long> {
}
